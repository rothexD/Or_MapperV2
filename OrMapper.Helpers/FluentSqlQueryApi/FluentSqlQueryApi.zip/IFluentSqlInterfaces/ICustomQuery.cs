﻿namespace OrMapper.Helpers.FluentSqlQueryApi.IFluentSqlInterfaces
{
    public interface ICustomQuery
    {
        public ISelect Select();
    }
}
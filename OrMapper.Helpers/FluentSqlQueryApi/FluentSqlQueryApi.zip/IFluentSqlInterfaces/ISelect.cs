﻿namespace OrMapper.Helpers.FluentSqlQueryApi.IFluentSqlInterfaces
{
    public interface ISelect
    {
        public IFrom Select(string[] param);
    }
}